# Personas

Primary: mindful skincare beginners. Secondary: ingredient-aware customers upgrading from harsh cleansers.