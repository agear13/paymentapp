# Positioning

Thirsty Turtl helps customers build sustainable skincare rituals with turtle-safe, barrier-respecting formulas.