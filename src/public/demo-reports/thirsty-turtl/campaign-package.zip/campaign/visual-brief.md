# Visual Brief

## instagramCarousel
- Format: 1080×1350 carousel (5 slides)
- Dimensions: 1080×1350
- Concept: Step-by-step routine cards with product flat-lay photography
- Notes: Use soft natural light, muted earth tones, minimal text per slide

## facebook
- Format: 1200×630 link preview
- Dimensions: 1200×630
- Concept: Hero product with headline overlay and subtle texture background
- Notes: Keep headline under 8 words for mobile legibility

## pinterest
- Format: 1000×1500 pin
- Dimensions: 1000×1500
- Concept: Vertical infographic summarising the 10 tips
- Notes: Include numbered steps and brand logo lockup at base

## stories
- Format: 1080×1920 story sequence
- Dimensions: 1080×1920
- Concept: 3-frame story: hook → tip highlight → CTA swipe-up
- Notes: Use motion-safe safe zones; CTA on final frame only

## newsletterHeader
- Format: 600×200 email header
- Dimensions: 600×200
- Concept: Wide banner with product trio and campaign title
- Notes: Optimise for dark and light email clients
