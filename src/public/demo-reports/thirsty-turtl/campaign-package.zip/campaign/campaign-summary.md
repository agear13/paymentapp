# Campaign Summary

**Campaign:** Thirsty Turtl — Gentle Cleanser Education Campaign
**Type:** blog
**Business goal:** Educate customers on barrier-friendly daily cleansing routines
**Target audience:** Health-conscious adults with sensitive skin seeking gentle skincare