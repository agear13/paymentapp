# Creative Asset Checklist

## Instagram Carousel
- [ ] Product Photography
- [ ] Lifestyle Photography
- [ ] Brand Colours
- [ ] Typography
- [ ] Logo

## Facebook Post
- [ ] Hero Image
- [ ] Campaign Headline
- [ ] Brand Colours
- [ ] Logo

## Pinterest Pin
- [ ] Product Image
- [ ] Educational Headline
- [ ] Brand Palette

## Instagram Story
- [ ] Vertical Photography
- [ ] Swipe CTA
- [ ] Brand Colours
- [ ] Typography

## Newsletter Header
- [ ] Hero Image
- [ ] Campaign Title
- [ ] CTA
